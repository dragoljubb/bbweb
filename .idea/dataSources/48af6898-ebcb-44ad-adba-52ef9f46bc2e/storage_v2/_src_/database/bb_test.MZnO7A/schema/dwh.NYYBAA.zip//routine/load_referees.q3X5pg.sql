create procedure load_referees()
    language sql
as
$$
INSERT INTO dwh.referees(
	ref_code, ref_name, ref_alias, ref_active, image_vertical_small, country_code)
	SELECT ref_code, ref_name, ref_alias, ref_active, image_vertical_small, country_code
	FROM stg.referees
$$;

alter procedure load_referees() owner to postgres;

