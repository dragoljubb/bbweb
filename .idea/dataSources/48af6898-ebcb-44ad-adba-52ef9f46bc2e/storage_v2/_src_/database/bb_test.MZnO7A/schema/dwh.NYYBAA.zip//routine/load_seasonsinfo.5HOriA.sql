create procedure load_seasonsinfo()
    language sql
as
$$
INSERT INTO dwh.seasons_info(
season_code, season_name, season_year, season_alias, compcode, start_date, end_date, activation_date, winner_code, winner_name, winner_tv_code, winner_is_virtual, winner_abbreviated_name, winner_crest)
SELECT season_code, season_name, season_year, season_alias, compcode, start_date, end_date, activation_date, winner_code, winner_name, winner_tv_code, winner_is_virtual, winner_abbreviated_name, winner_crest
FROM stg.seasons_info 
ORDER BY id
$$;

alter procedure load_seasonsinfo() owner to postgres;

