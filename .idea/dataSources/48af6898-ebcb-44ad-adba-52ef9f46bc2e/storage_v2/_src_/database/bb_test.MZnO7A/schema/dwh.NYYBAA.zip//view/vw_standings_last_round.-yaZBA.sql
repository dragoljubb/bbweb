create view vw_standings_last_round(season_code, last_round) as
SELECT season_code,
       max(round) AS last_round
FROM dwh.vw_standings
GROUP BY season_code;

alter table vw_standings_last_round
    owner to postgres;

grant select on vw_standings_last_round to user_view;

