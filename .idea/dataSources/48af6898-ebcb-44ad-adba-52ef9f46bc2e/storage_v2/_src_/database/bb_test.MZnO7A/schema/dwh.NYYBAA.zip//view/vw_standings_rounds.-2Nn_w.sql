create view vw_standings_rounds(season_code, round) as
SELECT DISTINCT season_code,
                round
FROM dwh.vw_standings;

alter table vw_standings_rounds
    owner to postgres;

grant select on vw_standings_rounds to user_view;

