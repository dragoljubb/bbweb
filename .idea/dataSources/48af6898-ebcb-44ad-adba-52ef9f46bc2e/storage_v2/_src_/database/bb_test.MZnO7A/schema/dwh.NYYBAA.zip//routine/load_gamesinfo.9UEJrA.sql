create procedure load_gamesinfo()
    language plpgsql
as
$$
BEGIN
    INSERT INTO dwh.gamesinfo (
    game_code,
    round,
	season_year,
	compcode,
	phase,
	game_date,
    home_code,
    home_score,
	home_standings_score,
    away_code,
    away_score,
	away_standings_score,
    played,
    referee1_code,
    referee2_code,
    referee3_code,
    arena_code
    
    )
    SELECT 
        g.game_code,
        r.round,
		r.season_year,
		r.compcode,
		r.phase,
		g.game_date,
        g.local_club_code,
        NULLIF(g.local_score, 0),
		NULLIF(g.local_standings_score,0),
        g.road_club_code,
        NULLIF(g.road_score, 0),
		NULLIF(g.road_standings_score, 0),
        g.played,
        r1.ref_code AS referee1_code,
        r2.ref_code AS referee2_code,
        r3.ref_code AS referee3_code,
		NULL
    FROM stg.gamesreport g
    INNER JOIN dwh.seasons s 
        ON s.season_year = g.src_season
       AND s.compcode = g.src_compcode
    INNER JOIN dwh.rounds r 
        ON r.season_year = s.season_year
       AND r.round = g.round
       AND r.phase = g.phase_type_code
	 LEFT JOIN stg.gamesheader h
	 ON CAST(h.src_season AS INTEGER) = s.season_year
	 	AND g.src_gamecode = h.src_gamecode 
		AND s.compcode = h.src_compcode
	 LEFT JOIN dwh.referees r1 
	   ON r1.ref_name = h.referee1
	 LEFT JOIN dwh.referees r2 
	   ON r2.ref_name = h.referee2
	 LEFT JOIN dwh.referees r3 
	   ON r3.ref_name = h.referee3
    ON CONFLICT (game_code, round, season_year, compcode)
    DO UPDATE
        SET home_code            =  EXCLUDED.home_code,
            home_score           =  NULLIF(EXCLUDED.home_score, 0),
			home_standings_score =  NULLIF(EXCLUDED.home_standings_score,0),
            away_code            =  EXCLUDED.away_code,
            away_standings_score =  NULLIF(EXCLUDED.away_standings_score,0),
            away_score       	 =  NULLIF(EXCLUDED.away_score,0),
            played           	 =  EXCLUDED.played,
            game_date        	 =  EXCLUDED.game_date,
			referee1_code    	 =  EXCLUDED.referee1_code,
			referee2_code    	 =  EXCLUDED.referee2_code,
			referee3_code    	 =  EXCLUDED.referee3_code;
END;
$$;

alter procedure load_gamesinfo() owner to postgres;

