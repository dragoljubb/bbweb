create view vw_rounds
            (season_year, season_code, compcode, round, phase, round_name, round_index, dates_formatted, min_game_start,
             max_game_start)
as
SELECT r.season_year,
       s.season_alias AS season_code,
       r.compcode,
       r.round,
       r.phase,
       r.round_name,
       r.round_index,
       r.dates_formatted,
       r.min_game_start,
       r.max_game_start
FROM dwh.rounds r
         JOIN dwh.seasons s ON s.compcode = r.compcode AND s.season_year = r.season_year
ORDER BY r.compcode, r.phase, r.season_year, r.round;

alter table vw_rounds
    owner to postgres;

grant select on vw_rounds to user_view;

