create view vw_news_home(id, newstitle, newslead, newscontent, image_url, created) as
SELECT id,
       newstitle,
       newslead,
       newscontent,
       image_url,
       created
FROM dwh.news
ORDER BY created DESC
LIMIT 6;

alter table vw_news_home
    owner to postgres;

grant select on vw_news_home to user_view;

