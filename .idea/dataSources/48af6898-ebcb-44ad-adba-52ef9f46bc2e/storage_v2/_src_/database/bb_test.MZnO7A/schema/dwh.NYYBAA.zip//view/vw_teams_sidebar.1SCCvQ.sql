create view vw_teams_sidebar(team_code, team_name, team_alias, compcode, season_year, crest_url) as
SELECT DISTINCT t.team_code,
                t.team_name,
                t.team_alias,
                g.compcode,
                g.season_year,
                t.crest_url
FROM dwh.teamsinfo t
         JOIN dwh.gamesinfo g ON g.away_code = t.team_code OR g.home_code = t.team_code;

alter table vw_teams_sidebar
    owner to postgres;

grant select on vw_teams_sidebar to user_view;

