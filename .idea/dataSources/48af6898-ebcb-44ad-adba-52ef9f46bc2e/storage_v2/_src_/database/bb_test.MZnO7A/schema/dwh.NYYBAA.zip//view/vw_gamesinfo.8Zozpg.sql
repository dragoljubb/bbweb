create view vw_gamesinfo
            (game_code, round, season_year, season_code, compcode, game_date, home_code, home_code_tv, home_score,
             home_standings_score, away_code, away_code_tv, away_score, away_standings_score, played, referee1_code,
             referee2_code, referee3_code, arena_code, home_crest, away_crest)
as
SELECT g.game_code,
       g.round,
       g.season_year,
       s.season_alias  AS season_code,
       g.compcode,
       g.game_date,
       g.home_code,
       t1.team_code_tv AS home_code_tv,
       g.home_score,
       g.home_standings_score,
       g.away_code,
       t2.team_code_tv AS away_code_tv,
       g.away_score,
       g.away_standings_score,
       g.played,
       g.referee1_code,
       g.referee2_code,
       g.referee3_code,
       g.arena_code,
       t1.crest_url    AS home_crest,
       t2.crest_url    AS away_crest
FROM dwh.gamesinfo g
         JOIN dwh.teamsinfo t1 ON t1.team_code = g.home_code
         JOIN dwh.teamsinfo t2 ON t2.team_code = g.away_code
         JOIN dwh.seasons s ON s.season_year = g.season_year AND s.compcode = g.compcode;

alter table vw_gamesinfo
    owner to postgres;

grant select on vw_gamesinfo to user_view;

