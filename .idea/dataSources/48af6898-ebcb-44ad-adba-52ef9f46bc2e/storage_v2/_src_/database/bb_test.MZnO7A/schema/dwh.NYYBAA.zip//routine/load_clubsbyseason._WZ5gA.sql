create procedure load_clubsbyseason()
    language sql
as
$$

INSERT INTO dwh.clubsbyseason (
    season_year,
    compcode,
    club_code,
    club_name,
    city,
    phone,
    crest_url,
    tv_code,
    address,
    country_code,
    country_name,
    sponsor,
    website,
    is_virtual,
    president,
    venue_code,
    tickets_url,
    editorial_name,
    twitter_account,
    abbreviated_name,
    club_permanent_name,
    club_permanent_alias
)
SELECT
    src_season_year,
    src_compcode,
    club_code,
    club_name,
    city,
    phone,
    crest_url,
    tv_code,
    address,
    country_code,
    country_name,
    sponsor,
    website,
    is_virtual,
    president,
    venue_code,
    tickets_url,
    editorial_name,
    twitter_account,
    abbreviated_name,
    club_permanent_name,
    club_permanent_alias
FROM stg.clubsbyseason
ON CONFLICT (season_year, compcode, club_code)
DO UPDATE SET
    club_name            = EXCLUDED.club_name,
    city                 = EXCLUDED.city,
    phone                = EXCLUDED.phone,
    crest_url            = EXCLUDED.crest_url,
    tv_code              = EXCLUDED.tv_code,
    address              = EXCLUDED.address,
    country_code         = EXCLUDED.country_code,
    country_name         = EXCLUDED.country_name,
    sponsor              = EXCLUDED.sponsor,
    website              = EXCLUDED.website,
    is_virtual           = EXCLUDED.is_virtual,
    president            = EXCLUDED.president,
    venue_code           = EXCLUDED.venue_code,
    tickets_url          = EXCLUDED.tickets_url,
    editorial_name       = EXCLUDED.editorial_name,
    twitter_account      = EXCLUDED.twitter_account,
    abbreviated_name     = EXCLUDED.abbreviated_name,
    club_permanent_name  = EXCLUDED.club_permanent_name,
    club_permanent_alias = EXCLUDED.club_permanent_alias;
$$;

alter procedure load_clubsbyseason() owner to postgres;

