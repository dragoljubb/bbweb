create view vw_seasons
            (season_year, compcode, season_name, season_code, season_info_alias, winner_code, winner_tv_code,
             start_date, end_date, activation_date)
as
SELECT season_year,
       compcode,
       season_name,
       season_alias AS season_code,
       season_info_alias,
       winner_code,
       winner_tv_code,
       start_date,
       end_date,
       activation_date
FROM dwh.seasons;

alter table vw_seasons
    owner to postgres;

grant select on vw_seasons to user_view;

