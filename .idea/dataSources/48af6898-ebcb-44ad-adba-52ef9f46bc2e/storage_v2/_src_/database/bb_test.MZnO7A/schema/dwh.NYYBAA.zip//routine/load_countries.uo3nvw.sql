create procedure load_countries()
    language sql
as
$$INSERT INTO dwh.Countries(code, country_name)
SELECT code, country_name FROM stg.Countries
WHERE code <>'0'
ORDER BY ID$$;

alter procedure load_countries() owner to postgres;

