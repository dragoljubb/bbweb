create view vw_standings
            (compcode, season_year, season_code, round, team_code, team_tvcode, team_name, crest_url, phase_name,
             phasetype_name, team_position, games_played, games_lost, points_for, points_against, points_diff,
             home_record, away_record, neutral_record, overtime_record, last5_form, last_ten_record, win_percentage,
             qualified, position_change)
as
SELECT s.compcode,
       s.season_year,
       ss.season_alias AS season_code,
       s.round,
       s.team_code,
       s.team_tvcode,
       s.team_name,
       s.crest_url,
       s.group_code    AS phase_name,
       p.phasetype_name,
       s.team_position,
       s.games_played,
       s.games_lost,
       s.points_for,
       s.points_against,
       s.points_diff,
       s.home_record,
       s.away_record,
       s.neutral_record,
       s.overtime_record,
       s.last5_form,
       s.last_ten_record,
       s.win_percentage,
       s.qualified,
       s.position_change
FROM dwh.standings s
         JOIN dwh.phasetypes p ON p.code = s.group_code
         JOIN dwh.seasons ss ON s.season_year = ss.season_year AND ss.compcode = s.compcode;

alter table vw_standings
    owner to postgres;

grant select on vw_standings to user_view;

