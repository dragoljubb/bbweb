create procedure load_standings()
    language plpgsql
as
$$
BEGIN
    INSERT INTO dwh.standings (
    compcode, 
	season_year, 
	round, 
	team_code, 
	team_tvcode, 
	team_name, 
	crest_url, 
	group_code, 
	isvirtual, 
	editorial_name, 
	abbreviated_name, 
	team_position, 
	games_played, 
	games_won, 
	games_lost, 
	points_for, 
	points_against, 
	points_diff, 
	home_record, 
	away_record, 
	neutral_record, 
	overtime_record, 
	last5_form, 
	last_ten_record, 
	win_percentage, 
	qualified, 
	position_change
    
    )
    SELECT 
	s.src_compcode, 
	s.src_season_year, 
	s.src_round, 
	s.team_code, 
	s.team_tvcode, 
	s.team_name, 
	s.crest_url, 
	r.phase, 
	s.isvirtual, 
	s.editorial_name, 
	s.abbreviated_name, 
	s.team_position, 
	s.games_played, 
	s.games_won, 
	s.games_lost, 
	s.points_for, 
	s.points_against, 
	s.points_diff, 
	s.home_record, 
	s.away_record, 
	s.neutral_record, 
	s.overtime_record, 
	s.last5_form, 
	s.last_ten_record, 
	s.win_percentage, 
	s.qualified, 
	s.position_change
    FROM stg.standings s
    INNER JOIN dwh.seasons ss 
        ON ss.season_year = s.src_season_year
       AND ss.compcode = s.src_compcode
	INNER JOIN dwh.phasetypes p
	ON p.phasetype_name = s.group_name
    INNER JOIN dwh.rounds r 
        ON r.season_year = ss.season_year
       AND r.round = s.src_round
       AND r.phase = p.code
    ON CONFLICT (compcode, round, season_year, team_code)
    DO UPDATE
        SET team_tvcode			= 	EXCLUDED.team_tvcode, 
	        team_name			= 	EXCLUDED.team_name, 
			crest_url  			= 	EXCLUDED.crest_url, 
			group_code  		= 	EXCLUDED.group_code, 
			isvirtual   		=   EXCLUDED.isvirtual,
			editorial_name  	=   EXCLUDED.editorial_name,
			abbreviated_name 	= 	EXCLUDED.abbreviated_name,
			team_position 		= 	EXCLUDED.team_position, 
			games_played		= 	EXCLUDED.games_played, 
			games_won			= 	EXCLUDED.games_won,
			games_lost			= 	EXCLUDED.games_lost,
			points_for			= 	EXCLUDED.points_for, 
			points_against		= 	EXCLUDED.points_against,
			points_diff			= 	EXCLUDED.points_diff,
			home_record			= 	EXCLUDED.home_record,
			away_record			= 	EXCLUDED.away_record,
			neutral_record		= 	EXCLUDED.neutral_record, 
			overtime_record		= 	EXCLUDED.overtime_record,
			last5_form			= 	EXCLUDED.last5_form,
			last_ten_record		= 	EXCLUDED.last_ten_record,	
			win_percentage		= 	EXCLUDED.win_percentage,	 
			qualified			= 	EXCLUDED.qualified,
			position_change		= 	EXCLUDED.position_change;
END;
$$;

alter procedure load_standings() owner to postgres;

