create view vw_current_season
            (season_year, compcode, season_name, season_code, season_info_alias, winner_code, winner_tv_code,
             start_date, end_date, activation_date)
as
SELECT season_year,
       compcode,
       season_name,
       season_code,
       season_info_alias,
       winner_code,
       winner_tv_code,
       start_date,
       end_date,
       activation_date
FROM dwh.vw_seasons
WHERE start_date <= now()
  AND (end_date IS NULL OR end_date >= now())
ORDER BY compcode, season_year;

alter table vw_current_season
    owner to postgres;

grant select on vw_current_season to user_view;

