create function update_last_update() returns trigger
    language plpgsql
as
$$
BEGIN
   NEW.last_update = CURRENT_TIMESTAMP;
   RETURN NEW;
END;
$$;

alter function update_last_update() owner to postgres;

