create procedure load_arenas()
    language sql
as
$$
INSERT INTO dwh.arenas(
		arena_code, 
		arena_name,
		notes,
		active,
		address,
		capacity)
SELECT arena_code, 
		arena_name,
		notes,
		active,
		address,
		capacity FROM stg.arenas
ORDER BY ID
$$;

alter procedure load_arenas() owner to postgres;

