create procedure load_seasons()
    language sql
as
$$
INSERT INTO dwh.seasons(
	season_year,
	compcode,
	season_name,
    season_alias,
	season_info_alias,
	winner_code,
	winner_tv_code,
	start_date,
	end_date,
	activation_date
	)
SELECT 
    s.season_year,
	c.code,
	s.season_name,
    s.season_alias,
    i.season_alias,
	i.winner_code,
	i.winner_tv_code,
	i.start_date,
	i.end_date,
	i.activation_date
FROM stg.seasons s

INNER JOIN stg.seasons_info i
	ON i.season_year = s.season_year 
		AND i.compcode = s.comp_code
INNER JOIN dwh.competitions c
	ON c.code = s.comp_code
ORDER BY s.id
$$;

alter procedure load_seasons() owner to postgres;

