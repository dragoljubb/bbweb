create view vw_phases(code, phasetype_name, alias_name, default_order) as
SELECT code,
       phasetype_name,
       alias_name,
       default_order
FROM dwh.phasetypes;

alter table vw_phases
    owner to dbb;

