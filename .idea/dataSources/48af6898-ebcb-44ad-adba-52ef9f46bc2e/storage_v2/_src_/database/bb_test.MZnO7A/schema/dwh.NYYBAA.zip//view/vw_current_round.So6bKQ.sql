create view vw_current_round
            (id, season_year, compcode, round, phase, round_name, round_index, dates_formatted, min_game_start,
             max_game_start, created, updated)
as
SELECT id,
       season_year,
       compcode,
       round,
       phase,
       round_name,
       round_index,
       dates_formatted,
       min_game_start,
       max_game_start,
       created,
       updated
FROM dwh.rounds
WHERE min_game_start <= now()
  AND (max_game_start IS NULL OR max_game_start >= now())
ORDER BY compcode, season_year, phase, round;

alter table vw_current_round
    owner to postgres;

grant select on vw_current_round to user_view;

