create function get_team_games(p_team_code text, p_season_code text)
    returns TABLE(home_code text, away_code text, game_date timestamp without time zone, game_status text, home_score integer, away_score integer, played boolean)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    WITH cteTeamGames AS (
        SELECT i1.home_code as team_code, i1.game_code as game_code, i1.game_date as game_date, i1.played as played FROM dwh.vw_gamesinfo i1
        WHERE i1.home_code = p_team_code AND i1.season_code = p_season_code
        UNION ALL
        SELECT i2.away_code  as team_code, i2.game_code as game_code, i2.game_date as game_date, i2.played as played FROM dwh.vw_gamesinfo i2
        WHERE i2.away_code = p_team_code AND i2.season_code = p_season_code
    ),
    cteNextGame AS (
        SELECT * FROM cteTeamGames 
        WHERE cteTeamGames.played = false AND cteTeamGames.game_date > NOW()
        ORDER BY cteTeamGames.game_date
        LIMIT 1
    )
    SELECT i.home_code,
           i.away_code,
           i.game_date,
           CASE
               WHEN n.game_code IS NOT NULL THEN 'NEXT'
               WHEN i.game_date < NOW() AND i.played = true THEN 'RESULT'
               ELSE 'UPCOMING'
           END AS game_status,
		   i.home_score,
		   i.away_score,
		   i.played
    FROM dwh.vw_gamesinfo i
    LEFT JOIN cteNextGame n ON n.game_code = i.game_code
    WHERE p_team_code IN (i.home_code, i.away_code)
      AND i.season_code = p_season_code
    ORDER BY i.game_date;
END;
$$;

alter function get_team_games(text, text) owner to postgres;

