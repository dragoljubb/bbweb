create view vw_clubsbyseason
            (id, season_year, season_code, compcode, club_code, club_name, city, phone, crest_url, tv_code, address,
             country_code, country_name, sponsor, website, is_virtual, president, venue_code, tickets_url,
             editorial_name, twitter_account, abbreviated_name, club_permanent_name, club_permanent_alias)
as
SELECT c.id,
       c.season_year,
       s.season_alias AS season_code,
       c.compcode,
       c.club_code,
       c.club_name,
       c.city,
       c.phone,
       c.crest_url,
       c.tv_code,
       c.address,
       c.country_code,
       c.country_name,
       c.sponsor,
       c.website,
       c.is_virtual,
       c.president,
       c.venue_code,
       c.tickets_url,
       c.editorial_name,
       c.twitter_account,
       c.abbreviated_name,
       c.club_permanent_name,
       c.club_permanent_alias
FROM dwh.clubsbyseason c
         JOIN dwh.seasons s ON s.compcode = c.compcode AND s.season_year = c.season_year;

alter table vw_clubsbyseason
    owner to postgres;

grant select on vw_clubsbyseason to user_view;

