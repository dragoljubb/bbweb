create function set_updated() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated = NOW();
    RETURN NEW;
END;
$$;

alter function set_updated() owner to postgres;

