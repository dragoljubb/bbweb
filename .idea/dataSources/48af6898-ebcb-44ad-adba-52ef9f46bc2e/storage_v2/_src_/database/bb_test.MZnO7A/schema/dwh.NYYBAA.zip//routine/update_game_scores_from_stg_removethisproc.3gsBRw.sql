create procedure update_game_scores_from_stg_removethisproc()
    language plpgsql
as
$$
BEGIN
    UPDATE dwh.gameinfo i
    SET
        local_score = g.score_a,
        road_score  = g.score_b
    FROM dwh.rounds r
    JOIN dwh.seasons s
        ON s.id = r.id_seasons
    JOIN stg.gamesheader g
        ON g.src_compcode = s.comp_code
    WHERE i.round_id = r.id
      AND i.game_code = g.src_gamecode   -- ✅ OVDE IDE
      AND r.phase = 'RS'
      AND (i.local_score = 0 OR i.road_score = 0);
END;
$$;

alter procedure update_game_scores_from_stg_removethisproc() owner to postgres;

