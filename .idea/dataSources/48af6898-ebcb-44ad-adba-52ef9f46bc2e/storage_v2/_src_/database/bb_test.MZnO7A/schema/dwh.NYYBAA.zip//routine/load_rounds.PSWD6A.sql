create procedure load_rounds()
    language sql
as
$$
INSERT INTO dwh.rounds(
	season_year, compcode, round, round_index, phase, round_name, dates_formatted, min_game_start, max_game_start)
SELECT s.season_year, 
        s.compcode,
	    r.round,
		r.round_index, 
		p.code,
		r.round_name,
		r.dates_formatted,
		r.min_game_start,
		r.max_game_start
FROM stg.rounds r
INNER JOIN dwh.phasetypes p
ON p.code = r.phase_type
INNER JOIN dwh.seasons s
ON r.src_compcode = s.compcode AND r.src_season = s.season_year
		
		
	   
 
$$;

alter procedure load_rounds() owner to postgres;

