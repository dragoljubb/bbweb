create view vw_comp_phases
            (phase, compcode, season_year, season_code, phasetype_name, alias_name, default_order, isgroupphase) as
WITH ctephases AS (SELECT DISTINCT gamesinfo.compcode,
                                   gamesinfo.phase,
                                   gamesinfo.season_year
                   FROM dwh.gamesinfo)
SELECT c.phase,
       c.compcode,
       c.season_year,
       s.season_alias AS season_code,
       p.phasetype_name,
       p.alias_name,
       p.default_order,
       p.isgroupphase
FROM dwh.phasetypes p
         JOIN ctephases c ON c.phase = p.code
         JOIN dwh.seasons s ON s.compcode = c.compcode AND s.season_year = c.season_year;

alter table vw_comp_phases
    owner to postgres;

grant select on vw_comp_phases to user_view;

