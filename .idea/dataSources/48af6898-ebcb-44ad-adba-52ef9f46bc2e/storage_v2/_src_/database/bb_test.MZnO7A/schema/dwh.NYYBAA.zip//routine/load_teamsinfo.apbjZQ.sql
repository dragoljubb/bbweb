create procedure load_teamsinfo()
    language sql
as
$$
INSERT INTO dwh.teamsinfo(
		team_code,
    	team_name,
    	team_alias,
    	city,
    	address,
    	phone,
    	fax,
    	website,
    	is_virtual,
    	president,
    	tickets_url,
    	twitter,
    	facebook,
    	instagram,
    	local_comp_code,
    	crest_url,
    	country_code,
    	arena_code)
SELECT  t.team_code,
    	t.team_name,
    	t.team_alias,
    	t.city,
    	t.address,
    	t.phone,
    	t.fax,
    	t.website,
    	t.is_virtual,
    	t.president,
    	t.tickets_url,
    	t.twitter,
    	t.facebook,
    	t.instagram,
    	t.local_comp_code,
    	t.crest_url,
    	c.country_code,
    	a.arena_code FROM stg.teamsinfo t
		INNER JOIN dwh.countries c
		ON c.country_code = t.country_code
		LEFT JOIN dwh.arenas a
		ON a.arena_code = t.venue_code
		ORDER BY t.id
$$;

alter procedure load_teamsinfo() owner to postgres;

