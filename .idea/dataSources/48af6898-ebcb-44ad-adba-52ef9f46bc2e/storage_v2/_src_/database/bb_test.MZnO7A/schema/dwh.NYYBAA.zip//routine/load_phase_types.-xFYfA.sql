create procedure load_phase_types()
    language sql
as
$$INSERT INTO dwh.phase_types(code, phasetype_name, alias_name, default_order, isgroupphase)
SELECT code, 
       phasetype_name, 
	   alias_name, 
	   default_order, 
	   isgroupphase
FROM stg.phase_types
ORDER BY code$$;

alter procedure load_phase_types() owner to postgres;

