create procedure load_competitions()
    language sql
as
$$INSERT INTO dwh.competitions(code, comp_name)
SELECT code, comp_name FROM stg.competitions
ORDER BY code$$;

alter procedure load_competitions() owner to postgres;

