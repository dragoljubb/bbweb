create function set_last_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.last_update = NOW();
    RETURN NEW;
END;
$$;

alter function set_last_update() owner to postgres;

