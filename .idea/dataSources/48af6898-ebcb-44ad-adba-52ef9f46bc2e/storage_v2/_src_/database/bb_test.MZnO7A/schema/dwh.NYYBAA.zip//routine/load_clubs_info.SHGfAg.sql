create procedure load_clubs_info()
    language plpgsql
as
$$
BEGIN

    WITH cte as (SELECT DISTINCT club_code FROM dwh.clubsbyseason )
    INSERT INTO dwh.clubs_info (
	   club_code,
	   club_info
    )
    SELECT 
        s.src_club_code,
        s.club_info
		
    FROM stg.clubs_info s
    INNER JOIN cte  
        ON cte.club_code = s.src_club_code
      
    ON CONFLICT (club_code)
    DO UPDATE
        SET club_info            =  EXCLUDED.club_info   ;
END;
$$;

alter procedure load_clubs_info() owner to postgres;

